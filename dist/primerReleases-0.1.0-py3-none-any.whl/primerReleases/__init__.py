def saludar(Nombre):
    return "Hola " + Nombre + ", espero que estes bien"